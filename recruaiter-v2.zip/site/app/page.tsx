import { Nav } from "@/components/shared/Nav";
import { Hero } from "@/components/home/Hero";
import { WhoFor } from "@/components/home/WhoFor";
import { Why } from "@/components/home/Why";
import { Builds, type Build } from "@/components/home/Builds";
import { About } from "@/components/home/About";
import { FooterCta } from "@/components/home/FooterCta";
import { getBuilds } from "@/lib/notion/builds";

export const revalidate = 3600; // re-fetch Notion once an hour

export default async function HomePage() {
  const items: Build[] = await getBuilds();

  return (
    <>
      <Nav />
      <main>
        <Hero />
        <WhoFor />
        <Why />
        <Builds items={items} />
        <About />
      </main>
      <FooterCta />
    </>
  );
}
