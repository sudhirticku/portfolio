import { notion, text, select, date, url } from "./client";

export type Lesson = {
  id: string;
  title: string;
  summary: string;
  type?: string; // Webinar | YouTube | Workshop
  status?: string; // Upcoming | Recorded
  date?: string;
  link?: string; // YouTube URL, registration link, etc.
};

export async function getLessons(): Promise<Lesson[]> {
  const res = await notion.databases.query({
    database_id: process.env.NOTION_LEARN_DB!,
    filter: { property: "Published", checkbox: { equals: true } },
    sorts: [{ property: "Date", direction: "descending" }],
  });
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return res.results.map((page: any) => {
    const p = page.properties;
    return {
      id: page.id,
      title: text(p.Name),
      summary: text(p.Summary),
      type: select(p.Type),
      status: select(p.Status),
      date: date(p.Date),
      link: url(p.Link),
    };
  });
}

// Turns any youtube.com / youtu.be link into an embeddable URL, or returns undefined.
export function youtubeEmbed(link?: string) {
  if (!link) return;
  const m = link.match(/(?:v=|youtu\.be\/|shorts\/)([\w-]{11})/);
  return m ? `https://www.youtube.com/embed/${m[1]}` : undefined;
}
