import { notion, text, select } from "./client";
import type { Build } from "@/components/home/Builds";

// Adapt property names to whatever your existing Projects DB uses.
// Add the three new properties (Stage, Status, Effort) to that DB — see INSTRUCTIONS.md.
export async function getBuilds(): Promise<Build[]> {
  const res = await notion.databases.query({
    database_id: process.env.NOTION_PROJECTS_DB!,
    filter: { property: "Published", checkbox: { equals: true } },
    sorts: [{ property: "Order", direction: "ascending" }],
  });

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return res.results.map((page: any) => {
    const p = page.properties;
    return {
      id: page.id,
      title: text(p.Name),
      summary: text(p.Summary),
      stage: select(p.Stage),
      status: select(p.Status),
      effort: select(p.Effort),
    };
  });
}
