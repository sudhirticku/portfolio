import { NotionToMarkdown } from "notion-to-md";
import { notion, text, select, multi, date } from "./client";

export type Post = {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  date?: string;
  tags: string[];
  readTime?: string;
};

const n2m = new NotionToMarkdown({ notionClient: notion });

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function toPost(page: any): Post {
  const p = page.properties;
  return {
    id: page.id,
    slug: text(p.Slug),
    title: text(p.Name),
    excerpt: text(p.Excerpt),
    date: date(p.Date),
    tags: multi(p.Tags),
    readTime: select(p.ReadTime),
  };
}

export async function getPosts(): Promise<Post[]> {
  const res = await notion.databases.query({
    database_id: process.env.NOTION_BLOG_DB!,
    filter: { property: "Published", checkbox: { equals: true } },
    sorts: [{ property: "Date", direction: "descending" }],
  });
  return res.results.map(toPost);
}

export async function getPostBySlug(slug: string) {
  const res = await notion.databases.query({
    database_id: process.env.NOTION_BLOG_DB!,
    filter: {
      and: [
        { property: "Slug", rich_text: { equals: slug } },
        { property: "Published", checkbox: { equals: true } },
      ],
    },
  });
  const page = res.results[0];
  if (!page) return null;

  const blocks = await n2m.pageToMarkdown(page.id);
  const markdown = n2m.toMarkdownString(blocks).parent;
  return { post: toPost(page), markdown };
}
