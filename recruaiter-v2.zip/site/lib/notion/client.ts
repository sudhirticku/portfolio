import { Client } from "@notionhq/client";

export const notion = new Client({ auth: process.env.NOTION_TOKEN });

// Small helpers so each mapper stays readable.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const text = (p: any) =>
  p?.title?.map((t: any) => t.plain_text).join("") ??
  p?.rich_text?.map((t: any) => t.plain_text).join("") ??
  "";
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const select = (p: any) => p?.select?.name ?? p?.status?.name ?? undefined;
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const multi = (p: any): string[] => p?.multi_select?.map((s: any) => s.name) ?? [];
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const date = (p: any) => p?.date?.start ?? undefined;
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const url = (p: any) => p?.url ?? undefined;
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const checkbox = (p: any) => Boolean(p?.checkbox);
