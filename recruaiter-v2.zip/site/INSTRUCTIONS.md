# RecruAIter v2 — implementation guide

Assumes Next.js (App Router) + Tailwind + TypeScript + `@notionhq/client`. If your project differs, tell me which part and I'll adapt.

Budget: ~1 hour. Do it in this order and deploy after step 4 so you see progress early.

---

## 1. Drop the files in (10 min)

Copy the folders from this bundle into your project root, matching paths:

```
content/site.ts                 ← ALL copy lives here. Edit words here, never in components.
components/shared/*             ← Nav, Section, Button
components/home/*               ← Hero, WhoFor, Why, Builds, About, FooterCta
lib/notion/*                    ← client, builds, blog, learn
app/page.tsx                    ← REPLACES your current homepage
app/blog/page.tsx               ← new
app/blog/[slug]/page.tsx        ← new
app/learn/page.tsx              ← new
```

Two files are **snippets, not drop-ins** — merge them by hand:

- `app/globals.additions.css` → paste into your `app/globals.css`
- `app/layout.snippet.tsx` → merge the font + metadata into your `app/layout.tsx`

Then open `content/site.ts` and fill the three `TODO` links (LinkedIn, email, updates).

Check `tsconfig.json` has the `@/*` path alias (Next.js default). If not, add:
```json
"paths": { "@/*": ["./*"] }
```

## 2. Install packages (2 min)

```bash
npm i notion-to-md react-markdown @tailwindcss/typography
```

Add typography to `tailwind.config.ts`:
```ts
plugins: [require("@tailwindcss/typography")],
```
(If you're on Tailwind v4 with no config file, add `@plugin "@tailwindcss/typography";` to `globals.css` instead.)

## 3. Update your existing Projects database in Notion (10 min)

Your current Notion → Builds mapping keeps working. Add these properties to the Projects DB so cards can show tags:

| Property | Type | Options |
|---|---|---|
| `Summary` | Text | One line. End on the outcome for the recruiter. |
| `Stage` | Select | Sourcing · Screening · Outreach · Coordination · Intake / Strategy |
| `Status` | Select | Battle-tested · Testing · WIP |
| `Effort` | Select | No-code · Low-code · Needs a developer friend |
| `Published` | Checkbox | Only checked rows show on the site |
| `Order` | Number | Controls sort order on the homepage |

Then fix the Sourcer Junior row:
- **Summary:** Researches and sources candidates automatically from a brief — so you start the search with a shortlist, not a blank page.
- **Stage:** Sourcing · **Status:** Battle-tested (or whichever is true)

Open `lib/notion/builds.ts` and make sure the property names match yours (`Name`, `Summary`, `Stage`, `Status`, `Effort`, `Published`, `Order`). If your title column isn't called `Name`, change that one line.

## 4. Deploy the homepage

```bash
npm run dev      # check localhost:3000 — hero, who, why, builds, about, footer
git add . && git commit -m "v2: hero, who/why, builds, about" && git push
```
Vercel redeploys automatically. Blog and Learn will 500 until step 5 — that's expected.

## 5. Create two new Notion databases (15 min)

### Blog DB
| Property | Type | Notes |
|---|---|---|
| `Name` | Title | Post title |
| `Slug` | Text | URL-safe, e.g. `why-your-sourcing-agent-fails` |
| `Excerpt` | Text | 1–2 sentences shown in the list |
| `Date` | Date | Publish date |
| `Tags` | Multi-select | e.g. Sourcing, Mindset, Tooling |
| `ReadTime` | Select | e.g. "4 min read" |
| `Published` | Checkbox | |

Write the post body **inside the Notion page itself** — headings, bullets, code blocks, images all render. `notion-to-md` converts it.

### Learn DB (webinars + YouTube)
| Property | Type | Notes |
|---|---|---|
| `Name` | Title | |
| `Summary` | Text | |
| `Type` | Select | Webinar · YouTube · Workshop |
| `Status` | Select | Upcoming · Recorded |
| `Date` | Date | |
| `Link` | URL | YouTube link → auto-embeds. Any other link → shows a button. |
| `Published` | Checkbox | |

**Share both databases with your Notion integration** (⋯ menu → Connections → your integration). This is the step everyone forgets — without it you'll get `object_not_found`.

Grab each database ID from its URL: `notion.so/<workspace>/<DATABASE_ID>?v=...` (the 32-char string before `?v=`).

## 6. Environment variables

Add to `.env.local` **and** Vercel → Project → Settings → Environment Variables:

```
NOTION_TOKEN=secret_...            # you already have this
NOTION_PROJECTS_DB=...             # you already have this (rename if yours is different)
NOTION_BLOG_DB=...                 # new
NOTION_LEARN_DB=...                # new
```

Redeploy. `/blog` and `/learn` show friendly empty states until you add rows.

## 7. Clean-up checklist

- [ ] Delete your old hero/intro/about components if no longer imported.
- [ ] Your existing `/projects/[id]` page — keep it. Cards link to `/projects/${id}` as before. If the project page uses a slug instead, change the `href` in `components/home/Builds.tsx`.
- [ ] Your anime section is no longer on the homepage — it lives at `/anime` under "Off duty" in the nav. If you want it back on the homepage, add `<Anime />` after `<About />` in `app/page.tsx`.
- [ ] Update the OG image if you have one (title text: RecruAIter).
- [ ] Mobile check: the nav has six links now. Fine on tablet; on phones under 380px it wraps. If that bothers you, ask me for a hamburger version.

---

## How the pieces fit

```
Notion DBs ──▶ lib/notion/*.ts ──▶ app/*/page.tsx ──▶ components/*
                                          ▲
content/site.ts ──────────────────────────┘  (all static words)
```

- Change **words** → `content/site.ts`
- Change **colours / font** → `globals.css` variables + `layout.tsx`
- Add a **build, post or video** → add a row in Notion, tick Published. Site updates within an hour (`revalidate = 3600`), or redeploy to force it.

## Design decisions (so you can change them deliberately)

- **One bold element:** the giant "RecruAIter" wordmark with only "AI" in cobalt. Everything else is quiet on purpose so the pun carries the page.
- **Left-aligned two-column sections:** label + header on the left, content on the right. Reads like field notes, not a landing page.
- **Section order:** Hero → Who → Why → Builds → About. Reader feels seen before they browse; you show up once they care.
- **One typeface** (Instrument Sans) at three weights. Swap in `layout.tsx` if you prefer another — everything inherits.
- **Status badges** are the only coloured UI besides the accent — green for Battle-tested, amber for Testing, grey for WIP — because that honesty is the whole point of the site.
